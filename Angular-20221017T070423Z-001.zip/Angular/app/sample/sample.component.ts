import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample',
  template: `
  <h2>{{name}}</h2>
  <h2>{{person|json}}
  <h2>{{5.6775|number:'3.2-3'}}</h2>
  <h2>{{0.25|currency:'INR'}}</h2>
  <h2>{{date|date:'shortTime'}}</h2>
  `,
  styles: []
})
export class SampleComponent implements OnInit {
// public colors=["red","green","blue"];
// displayName=false;
// public color="green"
public name="prograd";
public message="Welcome to Prograd";
public person={
  "fname":"Ram",
  "lname":"Das"
}
public date=new Date();
  constructor() { }

  ngOnInit(): void {
  }


}
