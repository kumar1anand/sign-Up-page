import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'hello-world';
  public name="prograd";
  public image="https://www.gardendesign.com/pictures/images/675x529Max/site_3/helianthus-yellow-flower-pixabay_11863.jpg";
  styleProp="purple";
  public value:any= " " ;
  public greeting=" ";
  txtColor='green';
  styleClsProp='C3'
  Conditionclassprop='C8';
  onclick(){
    console.log("hey"); 
  }

  greet(event:any){
    console.log("hello");
    // this.greeting=event.type;
  }

  Bgcolor(d:string,e:string,f:string){
    console.log("BG color"+d+e+f);
  }

  getClsName(){
    return 'C3';
  }

}
